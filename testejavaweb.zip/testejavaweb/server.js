const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = 3000;

const videosDir = path.join(__dirname, 'public/videos');
if (!fs.existsSync(videosDir)) fs.mkdirSync(videosDir, { recursive: true });

// Configuração Multer
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, videosDir),
  filename: (req, file, cb) => cb(null, Date.now() + path.extname(file.originalname))
});
const upload = multer({ storage });

app.use(express.static('public'));
app.use(express.json());

// Funções para salvar e ler aulas
const DATA_FILE = 'aulas.json';
function lerAulas() { return fs.existsSync(DATA_FILE) ? JSON.parse(fs.readFileSync(DATA_FILE)) : []; }
function salvarAulas(aulas) { fs.writeFileSync(DATA_FILE, JSON.stringify(aulas, null, 2)); }

// Rota para adicionar aula
app.post('/adicionar', upload.single('video'), (req, res) => {
  // Multer processa o arquivo, campos de texto ficam em req.body
  const titulo = req.body.titulo?.trim();
  const categoria = req.body.categoria?.trim() || 'Sem categoria';
  
  if (!titulo || !req.file) return res.status(400).send('Faltam dados');

  const aulas = lerAulas();
  const novaAula = {
    id: Date.now(),
    titulo,
    categoria,
    arquivo: req.file.filename,
    nomeOriginal: req.file.originalname,
    url: `/videos/${req.file.filename}`
  };

  aulas.push(novaAula);
  salvarAulas(aulas);
  res.json(novaAula);
});

// Listar aulas
app.get('/aulas', (req, res) => res.json(lerAulas()));

// Remover aula
app.delete('/remover/:id', (req, res) => {
  let aulas = lerAulas();
  const id = parseInt(req.params.id);
  const aula = aulas.find(a => a.id === id);
  if (!aula) return res.status(404).send('Aula não encontrada');

  fs.unlinkSync(path.join(videosDir, aula.arquivo));
  aulas = aulas.filter(a => a.id !== id);
  salvarAulas(aulas);

  res.send('Aula removida');
});

app.listen(PORT, () => console.log(`Servidor rodando em http://localhost:${PORT} - server.js:67`));
